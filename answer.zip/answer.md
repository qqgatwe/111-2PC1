# 第1次練習-練習-PC1
>
>學號：111111203
><br />
>姓名：張紋綺
><br />
>作業撰寫時間：30 (mins，包含程式撰寫時間)
><br />
>最後撰寫文件日期：2023/10/15
>

本份文件包含以下主題：(至少需下面兩項，若是有多者可以自行新增)
- [x] 說明內容
- [x] 個人認為完成作業須具備觀念

## 說明程式與內容

1.git clone git@github.com/qqgatwe/111-2PC1 2.新增一個檔案A.txt輸入This is an apple.儲存關掉檔案 3.git commit 4.git push推送上去 
5.git pull 6.檢視 命令選擇區 git log 7.git branch testdev 8.git checkout testdev 9.新增一個檔案B.txt輸入This is a bear. 10.git commit 
11.git push推送上去 12.git pull 13.git checkout 切換到main分支 14.新增一個檔案B.txt輸入This is a cake.儲存關掉檔案 15.git commit 16.git push推送上去

## 個人認為完成作業須具備觀念

要先熟悉git平台的基本工作原理與如何連線到終端機和建立SSH連線時要驗證key，在這次的作業中需要使用git commit提交、git push推送、由伺服器端git pull拉取最新的倉庫分支資料，在客戶端的倉庫中最新的倉庫裡進行對應分支合併，在做作業的過程中學到了很多指令，可以有效地使用git和github以確保代碼的運作和控制。